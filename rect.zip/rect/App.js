import { Text, StyleSheet, TextInput } from 'react-native';
import { useState} from 'react'

export default function App() {

  const [name, setName] = useState('')
  const handleName = (value) => {
    setName(value)
  }
  return( 

  <>
     <TextInput
      onChangeText = {handleName}
      placeholder= "Digite o seu nome: " 
     />
     <Text>Texto Digitado: {name}</Text>
  </>
  );
}

const styles = StyleSheet.create({

});
